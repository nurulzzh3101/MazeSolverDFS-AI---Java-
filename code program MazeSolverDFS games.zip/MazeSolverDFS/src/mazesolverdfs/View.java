/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mazesolverdfs;
import mazesolverdfs.DepthFirstSearch;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 * DISINI URUTAN 1-5, LALU LANJUT KE DepthFirstSearch.java
 * @author 690008
 */
public class View extends JFrame{

    /*(urutan 1)
    maze dalam bentuk array 2 dimensi
    value = 0=belum dikunjungi
            1=ada dinding / terblokir
            2=sudah dikunjungi
            9=goal state
    */
    //point start = (1,1)
     private int [][] maze = 
        { {1,1,1,1,1,1,1,1,1,1,1,1,1},
          {1,0,1,0,1,0,1,0,0,0,0,0,1},
          {1,0,1,0,0,0,1,0,1,1,1,0,1},
          {1,0,0,0,1,1,1,0,0,0,0,0,1},
          {1,0,1,0,0,0,0,0,1,1,1,0,1},
          {1,0,1,0,1,1,1,0,1,0,0,0,1},
          {1,0,1,0,1,0,0,0,1,1,1,0,1},
          {1,0,1,0,1,1,1,0,1,0,1,0,1},
          {1,0,0,0,0,0,0,0,0,0,1,9,1},
          {1,1,1,1,1,1,1,1,1,1,1,1,1}
        };
     
    //(lanjutan urutan 10)
    private final List<Integer> path = new ArrayList<Integer>();
    // balik lagi ke urutan 10
    // (lanjutan urutan 12 part 1)
    private int pathIndex;
    
    //(urutan 5) membuat window gambar maze
    public View(){
        setTitle("Penyelesaian Rute Maze memakai DFS");
        setSize(640, 640);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        /*(urutan 10)
        Pengechekan DFS
        Mengecek item pertama dan terakhir pada path list
        */
        DepthFirstSearch.searchPath(maze, 1, 1, path);// untuk melihat path line line 57, 58 di debug step over expression 2 kali
        pathIndex = path.size() - 2;// balik lagi ke urutan 12 (lanjutan urutan 12 part 2)
        //System.out.println(path);//sampe tanda panah hijau berada di kotak line 57
    }
    
    /* (urutan 12 BONUS)
    BONUS : mebuat bola bergerak melintasi path yang akan ditempuh
    menggunakan tombol kanan dan kiri
    */
    @Override
    protected void processKeyEvent(KeyEvent ke) {
        if (ke.getID() != KeyEvent.KEY_PRESSED) {
            return;
        }
        if (ke.getKeyCode() == KeyEvent.VK_RIGHT) {
            pathIndex -= 2;
            if(pathIndex < 0)
            {
                pathIndex =0;
            }
        }
        else if(ke.getKeyCode() == KeyEvent.VK_LEFT)
        {
            pathIndex += 2;
            if (pathIndex > path.size() - 2) 
            {
                pathIndex = path.size() - 2;
            }
        }
        repaint();
    }
    
    
    //(urutan 3) membuat gambar maze
    @Override
    public void paint(Graphics grphcs) {
        super.paint(grphcs); //To change body of generated methods, choose Tools | Templates.
        grphcs.translate(50, 50);
        //gambar maze
        for (int row = 0; row < maze.length; row++) {
            for (int col = 0; col < maze[0].length; col++) {
                Color color;
                switch (maze[row][col])
                {
                    case 1: color = Color.BLACK;break;
                    case 9: color = Color.RED;break;
                    default : color = Color.WHITE;
                }
                grphcs.setColor(color);
                grphcs.fillRect(30*col, 30*row, 30, 30);
                grphcs.setColor(Color.BLACK);
                grphcs.drawRect(30*col, 30*row, 30, 30);
            }
        }
        //(urutan 11) gambar path list
        for (int p = 0; p < path.size(); p+=2) {
            int pathX = path.get(p);
            int pathY = path.get(p + 1);
            grphcs.setColor(Color.GREEN);
            grphcs.fillRect(30*pathX, 30*pathY, 30, 30);
        }
        
        //(lanjutan urutan 12 part 3)
        int pathX = path.get(pathIndex);
        int pathY = path.get(pathIndex +1);
        grphcs.setColor(Color.RED);
        grphcs.fillOval(30*pathX, 30*pathY, 30, 30);
    }
    
    
    public static List<Integer> reverse(List<Integer> path){
        if (path.size() > 1) {
            int value = path.remove(0);
            reverse(path);
            path.add(value);             
        }
        return path;
    }
    //(urutan 4) menampilkan output maze
    public static void main(String[]args)
    { 
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
        View view = new View();
                view.setVisible(true);
        
                System.out.println("jika diurutkan dari goal state ke start state [kolom][baris] : ");
                System.out.println(view.path); 
                }
            }
        );      
        
        View view = new View();
        System.out.println("jika diurutkan dari start state ke goal state [baris][kolom] :  ");        
        System.out.println(reverse(view.path));
        
    }
    
}
