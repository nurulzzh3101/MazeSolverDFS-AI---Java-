/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mazesolverdfs;

import java.util.List;

/**
 *DISINI URUTAN 6-9, LALU KEMBALI LAGI KE View.java UNTUK URUTAN 10
 * @author 690008
 */
//(urutan 6)
//jika path nya ketemu, method ini akan mengembalikan nilai true
//path list akan terisi
//seperti ini : (xn, yn, ..., x2, y2, x1, y1)
//urutannya menjadi kebalik
//koor x = y dan koor y = x (row major pada java, row jadi col)
// x dan y pada method adalah start state nya
public class DepthFirstSearch {
    public static boolean searchPath (int [][]maze,int x, int y, List<Integer> path)
    { 
        /*(urutan 9)
        Pengecekan apakah target node telah tercapai
        */
        if(maze[y][x]==9)
        {
            path.add(x);
            path.add(y);
            return true;
        }
        /*(urutan 7)
        ketika posisi sekarang (x dan y) bukan path yang belum dikunjungi(value = 0)
        maka path akan ditandai telah dikunjungi (value = 2)
        */
        if(maze[y][x]==0)
        {
            maze[y][x]=2;
             /*(urutan 8)
            sekarang, mengunjungi node2 yang ada di sekitar secara rekursif
            jika ada path ketemu, maka path list akan diisi dengan posisi yang sekarang
            */
            int dx=-1;
            int dy=0;
            if(searchPath(maze, x+dx, y+dy, path))
            {
                path.add(x);
                path.add(y);
                return true;
            }
            
            dx=1;
            dy=0;
            if(searchPath(maze, x+dx, y+dy, path))
            {
                path.add(x);
                path.add(y);
                return true;
            }
            
            dx=0;
            dy=-1;
            if(searchPath(maze, x+dx, y+dy, path))
            {
                path.add(x);
                path.add(y);
                return true;
            }
            
            dx=0;
            dy=1;
            if(searchPath(maze, x+dx, y+dy, path))
            {
                path.add(x);
                path.add(y);
                return true;
            }
            
        }
        return false;
    }
}
